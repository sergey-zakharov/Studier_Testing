package ru.mipt.testing.rcd.testData;

/**
 * Class-container for data used for testing
 * */
public class TelephoneData {

	private String name;
	private String telephone;
    private String address;
    private String expectedType;
    private String expectedTelephone;
	private String expectedResult;
	
	public String getName(){
		return name;
	}
	
	public String getTelehone(){
		return telephone;
	}

    public String getAddress(){
        return address;
    }

    public String getExpectedType(){
        return expectedType;
    }

    public String getExpectedTelephone(){
        return expectedTelephone;
    }

    public String getExpectedResult(){
        return expectedResult;
    }
	
	public TelephoneData loadName(String name){
		this.name = name;
		return this;
	}
    public TelephoneData loadTelephone(String telephone){
        this.telephone = telephone;
        return this;
    }
    public TelephoneData loadAddress(String address){
        this.address = address;
        return this;
    }
	public TelephoneData loadExpectedType(String expectedType){
		this.expectedType = expectedType;
		return this;
	}
	public TelephoneData loadExpectedTelephone(String expectedTelephone){
		this.expectedTelephone = expectedTelephone;
		return this;
	}
    public TelephoneData loadExpectedResult(String expectedResult){
        this.expectedResult = expectedResult;
        return this;
    }
}
