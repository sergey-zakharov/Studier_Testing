package ru.mipt.testing.rcd.tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.mipt.testing.rcd.testData.TelephoneData;
import ru.mipt.testing.rcd.testData.TelephoneDataLoader;

public class LoginTest extends TestBase{

	@DataProvider
    public Iterator<Object[]> telephoneData() throws IOException {
        File loginDataFile = new File("test_data.csv");
        return wrapLoginsForDataProvider(TelephoneDataLoader.loadDataFromCsvFile(loginDataFile)).iterator();
    }

    @Test(dataProvider = "telephoneData")
    public void testLogin(TelephoneData telephoneData) throws Exception{
        assertEquals(app.getTelephoneHelper().doTelephoneCheck(telephoneData), telephoneData.getExpectedResult(), "Test telephone failed");
    }
}
