package ru.mipt.testing.rcd.fw;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AppManager {

    public String baseURL;
    public String mainPageURL;
    public WebDriver driver;


    private TelephoneHelper loginHelper = new TelephoneHelper(this);
    private NavigationHelper navigationHelper;



    public AppManager(){
		driver = new FirefoxDriver();
        this.baseURL = "https://dadata.ru/";
		driver.get(baseURL);
	}
	public void stop(){
		driver.close();
		driver.quit();
	}
	public TelephoneHelper getTelephoneHelper(){
        if (loginHelper == null) {
            loginHelper = new TelephoneHelper(this);
        }
		return loginHelper;
	}

    public NavigationHelper navigateTo() {
        if (navigationHelper == null) {
            navigationHelper = new NavigationHelper(this);
        }
        return navigationHelper;
    }

}
